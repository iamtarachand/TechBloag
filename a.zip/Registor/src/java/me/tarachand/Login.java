import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class Login extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the username and password from the request
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // In a real application, you would validate the username and password
        // against your user database. For this example, let's assume valid credentials.
        if (isValidUser(username, password)) {
            // Create a session and set the user attribute
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            
            response.sendRedirect("welcome.jsp"); // Redirect to a welcome page
        } else {
            // Invalid credentials, show an error message
            response.sendRedirect("login.html"); // Redirect back to the login page
        }
    }

    private boolean isValidUser(String username, String password) {
        // In a real application, validate the username and password against your user database
        // For this example, you can hardcode a valid user
        return "testuser".equals(username) && "password".equals(password);
    }
}
